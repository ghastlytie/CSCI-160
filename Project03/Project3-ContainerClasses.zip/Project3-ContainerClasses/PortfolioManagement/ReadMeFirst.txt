Be sure to put all of these files inside the Project folder once you have created the project.  There are several important files here: 

instructions.txt - some instructions for the project

implementationNotes.txt - has some suggestions about how to go about implementing the classes, and how to do the statistics and how to properly format the output. 

input data files: test0.txt, test1.txt, test2.txt use them one at a time as arguments in the project properties.  Your output should go to the console, the expected (correct) output is in the output files; out0.txt, out1.txt, out2.txt.

StockPortfolioManagementBasic.class.violet.html is the UML for this project.  USE IT.

if you get everything working with time to spare, open StockPortfolioManagementwithExtraCredit.class.violet.html to see the UML for the project with the extra credit added.