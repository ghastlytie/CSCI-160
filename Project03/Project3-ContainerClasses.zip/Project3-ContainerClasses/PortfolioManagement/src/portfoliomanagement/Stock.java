/**
 * File Name: Stock.java
 * Class: Stock
 * Author: Severen D. Denyer
 ***********************************************************************
 * Revision History - newest revisions first
 ***********************************************************************
 * 03/16/2024 - sdenyer - created the Stock class.
 *
 */
package portfoliomanagement;

/**
 * Description:
 *
 * @author sdenyer
 */
public class Stock {

    private String companyName = null;
    private double[] prices = null;
    private int[] trends;
    private double minimum;
    private double maximum;
    private double netChange;
    private double averagePrice;
    private double standardDeviation;
    private double bestUpwardTrendGrowthRate;
    private double highestMultiplier;
    private double highPeriod;
    private int longestUpwardTrend;
    private int periodOfBestGrowthRate;

    public Stock(String companyName, double[] prices) {
        this.companyName = companyName;
        this.prices = prices;
        calcMinMaxNetAndAverage();
        calcStdDev();
        calcLUT();
    }

    public Stock() {
        
    }

    private void calcMinMaxNetAndAverage() {
        double sum = 0.0;
        
        minimum = Double.MAX_VALUE;
        maximum = Double.MIN_VALUE;
        
        for (int i = 0; i < prices.length; i++) {
            if (prices[i] < minimum) {
                minimum = prices[i];
            }

            if (prices[i] > maximum) {
                maximum = prices[i];
            }

            netChange = Math.abs(prices[0] - prices[prices.length - 1]);

            sum += prices[i];
        }

        averagePrice = sum / prices.length;
    }

    private void calcStdDev() {
        double diffSqrSum = 0;
        
        for (int i = 0; i < prices.length; i++) {
            diffSqrSum += Math.pow((prices[i] - averagePrice), 2);
        }
        
        standardDeviation = Math.sqrt(diffSqrSum/prices.length);
    }

    private void calcLUT() {
        
        
        
        for (int i = 1; i < prices.length; i++) {
            if (prices[i] < prices[i-1]) {
                
            }
            System.out.print(prices[i] + ", ");
        }
        System.out.println();
        
        
    }

    private void calcBestGrowth() {
        
    }

    private void calcBestRateAndPeriod() {
        
    }

    public String getCompanyName() {
        return companyName;
    }

    public int getNumberOfPeriods() {
        return 0;
    }

    public int getNumberOfPrices() {
        return prices.length;
    }

    public int getNumberOfTrends() {
        return 0;
    }
    
    public double getTrendAt(int index) {
        return 0.0;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append(String.format("%-20s%6.1f%6.1f%7.1f%7.1f%7.2f%4d", companyName, minimum, maximum, netChange,
                averagePrice, standardDeviation,getNumberOfTrends()));  
        
        return str.toString();
    }

    public static void main(String[] args) {
        double[] quotes = {114.5, 120.6, 130.2, 128.1, 126.7, 129.3};
        String name = "Apple Inc";
        Stock s = new Stock(name, quotes);
        for (int i = 0; i < quotes.length; i++) {
            System.out.print(quotes[i] + ", ");
        }
        System.out.println();
        System.out.println(s);
        System.out.println("Expected Output without EC");
        System.out.println("Apple Inc.           114.5 130.2   14.8  "
                + "124.9   5.59   2     7.85");
    }
}
