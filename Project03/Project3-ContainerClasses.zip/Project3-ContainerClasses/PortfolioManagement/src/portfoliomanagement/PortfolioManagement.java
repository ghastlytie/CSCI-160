/**
 * File Name: PortfolioManagement.java
 * Class: PortfolioManagement
 * Author: Severen D. Denyer
 ***********************************************************************
 * Revision History - newest revisions first
 ***********************************************************************
 * 03/16/2024 - sdenyer - created the project and class.
 *                      -
 * 
 */

package portfoliomanagement;

/**
 * Description: 
 * @author sdenyer
 */
public class PortfolioManagement {
    
    private Portfolio portfolio;
    
    public void readFile(String fileName) {
        
    }
    
    public void run(String arg) {
        
    }
    
    public static void main(String[] args) {
        
    }

}
